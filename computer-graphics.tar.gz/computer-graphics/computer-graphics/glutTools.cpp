#include <GL/glut.h>
#include <list>
#include <algorithm>
#include "glutTools.h"

// ����
int glutTools::step = 1;
// �������
float glutTools::eps = 1e-4;
// ������ɫ
float* glutTools::Color::vertexRGB = nullptr;

// ��ǰ������
const glutApp* glutTools::app = nullptr;

// ������Ʊ��
bool glutTools::showGrid = false;
    
// ������ɫ
const glutTools::Color glutTools::VERTEX_COLOR = glutTools::Color(0, 0, 255);
// ������ɫ
const glutTools::Color glutTools::WINDOW_COLOR = glutTools::Color(255, 255, 255);
// ������ɫ
const glutTools::Color glutTools::GRID_COLOR = glutTools::Color(100, 100, 100);
// �����ɫ
const glutTools::Color glutTools::FILL_COLOR = glutTools::Color(200, 190, 250);
// ֱ����ɫ
const glutTools::Color glutTools::LINE_COLOR = glutTools::Color(255, 0, 0);
// �ü���ɫ
const glutTools::Color glutTools::CLIPED_COLOR = glutTools::Color(0, 100, 0);

// ��ȡ��p����ɫ
glutTools::Color glutTools::Color::get(const point p) {
	int x = p.x, y = p.y;
	// ����ת�±�
	int _index = ((app->getWindowHeight() - y) * app->getWindowWidth() + x) * 3;
	// Խ����
	if (_index < 0 || _index >= (app->getWindowWidth() + 1) * (app->getWindowHeight() + 1) * 3 - 3 || vertexRGB == nullptr)  return Color(0, 0, 0);
	return Color(vertexRGB[_index], vertexRGB[_index + 1], vertexRGB[_index + 2]);
}

// ���õ�p����ɫ
void glutTools::Color::set(const point p, const Color color) {
	int x = p.x, y = p.y;
	// ����ת�±�
	int _index = ((app->getWindowHeight() - y) * app->getWindowWidth() + x) * 3;
	// Խ����
	if (_index < 0 || _index >= (app->getWindowWidth() + 1) * (app->getWindowHeight() + 1) * 3 - 3 || vertexRGB == nullptr)  return;
	vertexRGB[_index] = color.r, vertexRGB[_index + 1] = color.g, vertexRGB[_index + 2] = color.b;
}

// ����
void glutTools::drawVertex(const point p, const Color color) {
	glBegin(GL_POINTS);
	glColor3f(color.r, color.g, color.b);
	glVertex2i(p.x, p.y);
	Color::set(p, color);
	glEnd();
}

// ����
void glutTools::drawLine(const point p0, const point p1, const Color color, bool overlap, const Color originColor) {
	{
		int x = p0.x, y = p0.y;
		int dx = abs(p1.x - x), dy = abs(p1.y - y);
		int sx = p0.x < p1.x ? step : -step;
		int sy = p0.y < p1.y ? step : -step;
		bool flag = 0;
		if (dy > dx) {
			std::swap(dx, dy);
			flag = 1;
		}
		int e = -dx;
		for (int i = 0; i * step < dx; ++i) {
			if (!overlap && Color::get(point(x, y)) == color) {
				drawVertex(point(x, y), originColor);
			}
			else {
				drawVertex(point(x, y), color);
			}
			if (flag) {
				y += sy, e += dy << 1;
				if (e >= 0) x += sx, e -= (dx << 1);
			}
			else {
				x += sx, e += dy << 1;
				if (e >= 0) y += sy, e -= (dx << 1);
			}
		}
	}
	if (!showGrid) return;
	glPointSize((10 * app->getWindowWidth()) / (12 * GRID_COLS));
	step = (12 * app->getWindowWidth()) / (10 * GRID_COLS);
	{
		int x = p0.x, y = p0.y;
		int dx = abs(p1.x - x), dy = abs(p1.y - y);
		int sx = p0.x < p1.x ? step : -step;
		int sy = p0.y < p1.y ? step : -step;
		bool flag = 0;
		if (dy > dx) {
			std::swap(dx, dy);
			flag = 1;
		}
		int e = -dx;
		for (int i = 0; i * step < dx; ++i) {
			drawVertex(point(x, y), VERTEX_COLOR);
			if (flag) {
				y += sy, e += dy << 1;
				if (e >= 0) x += sx, e -= (dx << 1);
			}
			else {
				x += sx, e += dy << 1;
				if (e >= 0) y += sy, e -= (dx << 1);
			}
		}
	}
	glPointSize(1);
	step = 1;
}

// ��Բ
void glutTools::drawCircle(const point p, int R, const Color color) {
	{
		int x = 0, y = R, d = 5 - 4 * R;
		glColor3f(color.r, color.g, color.b);
		while (x <= y) {
			drawVertex(point(x, y) + p, color);
			drawVertex(point(y, x) + p, color);
			drawVertex(point(-x, y) + p, color);
			drawVertex(point(y, -x) + p, color);
			drawVertex(point(x, -y) + p, color);
			drawVertex(point(-y, x) + p, color);
			drawVertex(point(-x, -y) + p, color);
			drawVertex(point(-y, -x) + p, color);
			if (d < 0) {
				d += 8 * x + 12;
			}
			else {
				d += 8 * (x - y) + 20, y -= step;
			}
			x += step;
		}
	}
	// glFlush();
	if (!showGrid) return;
	glPointSize(10);
	step = app->getWindowWidth() / GRID_COLS;
	{
		int x = 0, y = R, d = 5 - 4 * R;
		glColor3f(VERTEX_COLOR.r, VERTEX_COLOR.g, VERTEX_COLOR.b);
		while (x <= y) {
			drawVertex(point(x, y) + p, color);
			drawVertex(point(y, x) + p, color);
			drawVertex(point(-x, y) + p, color);
			drawVertex(point(y, -x) + p, color);
			drawVertex(point(x, -y) + p, color);
			drawVertex(point(-y, x) + p, color);
			drawVertex(point(-x, -y) + p, color);
			drawVertex(point(-y, -x) + p, color);
			if (d < 0) {
				d += 8 * x + 12;
			}
			else {
				d += 8 * (x - y) + 20, y -= step;
			}
			x += step;
		}
	}
	glPointSize(1);
	step = 1;
}

// ������
void glutTools::drawGrid(unsigned int row, unsigned int col, const Color color) {
	int width = app->getWindowWidth() / col;
	int height = app->getWindowHeight() / row;
	glBegin(GL_LINES);
	glColor3f(color.r, color.g, color.b);
	for (unsigned int i = 1; i <= row; ++i) {
		glVertex2i(height * i, 0), glVertex2i(height * i, app->getWindowWidth());
	}
	for (int i = 1; i <= col; ++i) {
		glVertex2i(0, width * i), glVertex2i(app->getWindowHeight(), width * i);
	}
	glEnd();
}

// ɨ�������
void glutTools::Xscan(std::vector<Line> vl) {
	bool showGrid_tmp = showGrid;
	showGrid = false;
	int minY = app->getWindowHeight(), maxY = 0;
	for (Line& l : vl) {
		if (l.p0.y > l.p1.y) std::swap(l.p0, l.p1);
		minY = std::min(minY, l.p0.y), maxY = std::max(maxY, l.p1.y);
	}
	struct ScanLine {
		int top;
		float k, x;
		ScanLine(Line l) {
			x = l.p0.x, top = l.p1.y;
			k = (float)(l.p0.x - l.p1.x) / (l.p0.y - l.p1.y);
		}
	};
	std::vector<std::vector<ScanLine>> NET(maxY - minY + 1);
	std::list<ScanLine> AET;
	for (const Line& l : vl) {
		if (l.p0.y == l.p1.y) continue;
		NET[l.p0.y - minY].push_back(ScanLine(l));
	}
	for (int i = 0; i < maxY - minY + 1; ++i) {
		for (auto it = AET.begin(); it != AET.end();) {
			if (it->top == i + minY) {
				it = AET.erase(it);
			}
			else {
				it->x += it->k;
				++it;
			}
		}
		for (ScanLine& l : NET[i]) AET.push_back(l);
		AET.sort([](const ScanLine a, const ScanLine b) -> bool {
			if (cmp(a.x, b.x) != 0) return cmp(a.x, b.x) < 0;
			if (cmp(a.k, b.k) != 0) return cmp(a.k, b.k) > 0;
			return a.top < b.top;
			});
		int cnt = 0;
		float last = 0;
		for (ScanLine& l : AET) {
			if (cnt & 1) drawLine(point(ceil(last), i + minY), point(floor(l.x), i + minY), FILL_COLOR);
			last = l.x;
			cnt++;
		}
	}
	showGrid = showGrid_tmp;
}
