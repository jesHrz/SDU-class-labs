#include <GL/glut.h>
#include <stdio.h>
#include "glutApp.h"
#include "glutTools.h"

static const unsigned int glutWidth = 800;
static const unsigned int glutHeight = 800;
static const unsigned int glutTopPostion = 500;
static const unsigned int glutLeftPostion = 300;

int glutLastWindow = 0;
int glutApp::s_argc = 0;
char** glutApp::s_argv = nullptr;
glutApp* glutApp::pCurrentApp = nullptr;

glutApp::glutApp() {
	displayMode = GLUT_RGB | GLUT_DOUBLE;
	menuCount = 0;
	cvalue = 0;
	title = nullptr;
	winWidth = glutWidth;
	winHeight = glutHeight;
	winTop = glutTopPostion;
	winLeft = glutLeftPostion;
}
glutApp::~glutApp() {
	glutTools::Color::destroy();
}
void glutApp::run() {
	glutApp* lastApp = pCurrentApp;
	pCurrentApp = this;

	glutApp* app = pCurrentApp;
	glutTools::setApp(app);
	if (!app) return;

	if (!app->winWidth) app->winWidth = glutWidth;
	if (!app->winHeight) app->winHeight = glutHeight;
	if (!app->winTop) app->winTop = glutTopPostion;
	if (!app->winLeft) app->winLeft = glutLeftPostion;

	if (!lastApp) {  // 第一次运行
		glutInit(&this->s_argc, this->s_argv);
	}
	else {
		glutDestroyWindow(glutLastWindow);
	}
	// 初始化窗口
	glutInitDisplayMode(this->displayMode);
	glutInitWindowPosition(app->winTop, app->winLeft);
	glutInitWindowSize(app->winWidth, app->winHeight);
	glutCreateWindow(app->title);
	glutLastWindow = glutGetWindow();
	printf("current window: %d size %dx%d at (%d,%d)\n", glutLastWindow, app->winWidth, app->winHeight, app->winTop, app->winLeft);

	app->onInit();
	// 注册键盘回调
	glutKeyboardFunc(glutApp::keyboardCallback);
	glutKeyboardUpFunc(glutApp::keyboardUpCallback);
	// 注册鼠标回调
	glutMouseFunc(glutApp::mousePressCallback);
	glutMotionFunc(glutApp::mousePressMoveCallback);
	glutPassiveMotionFunc(glutApp::mouseMoveCallback);

	menuRegister();

	// 注册绘制回调
	glutDisplayFunc(glutApp::displayCallback);
	// 注册空闲回调
	glutIdleFunc(glutApp::idleCallback);
	glutApp::idleCallback();

	glutMainLoop();
}
void glutApp::onInit() {
	glClearColor(glutTools::WINDOW_COLOR.r, glutTools::WINDOW_COLOR.g, glutTools::WINDOW_COLOR.b, 1);
	glClear(GL_COLOR_BUFFER_BIT);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0, getWindowWidth(), getWindowHeight(), 0);
}
void glutApp::keyboardCallback(unsigned char key, int x, int y) {
	glutApp::pCurrentApp->onKey(key, x, y);
}
void glutApp::keyboardUpCallback(unsigned char key, int x, int y) {
	glutApp::pCurrentApp->onKeyDown(key, x, y);
}
void glutApp::mousePressCallback(int button, int state, int x, int y) {
	glutApp::pCurrentApp->onMousePress(button, state, x, y);
}
void glutApp::mouseMoveCallback(int x, int y) {
	glutApp::pCurrentApp->onMouseMove(x, y);
}
void glutApp::mousePressMoveCallback(int x, int y) {
	glutApp::pCurrentApp->onMousePressMove(x, y);
}
void glutApp::displayCallback() {
	glutApp::pCurrentApp->onDisplay();
}
void glutApp::idleCallback() {
	glutApp::pCurrentApp->onIdle();
}
void glutApp::addMenuEntry(const char* name, int id, glutApp::menuFunc callback) {
	menuEntry[menuCount].id = id;
	menuEntry[menuCount].name = name;
	menuEntry[menuCount].callback = callback;
	menuCount++;
}
void glutApp::menuRegister() {
	if (menuCount <= 0) return;
	glutCreateMenu(menuCallback);
	for (int i = 0; i < menuCount; ++i) {
		glutAddMenuEntry(menuEntry[i].name, menuEntry[i].id);
	}
	glutAttachMenu(GLUT_RIGHT_BUTTON);
}
void glutApp::menuCallback(int id) {
	for (int i = 0; i < pCurrentApp->menuCount; ++i) {
		if (pCurrentApp->menuEntry[i].id == id) {
			pCurrentApp->onMenu(id);
			//pCurrentApp->cvalue = pCurrentApp->menuEntry[i].id;
			//pCurrentApp->menuEntry[i].callback();
			break;
		}
	}
}