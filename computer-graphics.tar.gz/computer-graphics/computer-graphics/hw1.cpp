#ifndef __hw1__
#define __hw1__

#include <GL/glut.h>
#include <cmath>
#include "glutApp.h"
#include "glutTools.h"

const int hw1_CIRCLEINRECT = 1;

class hw1 : public glutApp {
public:
	hw1(int argc = 0, char** argv = nullptr) {
		init(argc, argv);
		// ���ñ���
		setWindowTitle("hw1");
	}
private:
	int n = 0;
	void onInit() {
		glClearColor(glutTools::WINDOW_COLOR.r, glutTools::WINDOW_COLOR.g, glutTools::WINDOW_COLOR.b, 1);
		glClear(GL_COLOR_BUFFER_BIT);
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		gluOrtho2D(0, getWindowWidth(), getWindowHeight(), 0);

		// ���Ӳ˵���
		addMenuEntry("Circle in Rect", 1);
		addMenuEntry("Grid on/off", GRID);
		addMenuEntry("Clear", CLEAR);
		addMenuEntry("Exit", EXIT);
		printf("��Բ�з�\n");
	}
	void circle_in_rect(int n) {
		// �����ĵ�
		const glutTools::point p = glutTools::point(getWindowWidth() / 2, getWindowHeight() / 2);
		int r = getWindowWidth() / 2;
		for (int i = 0; i < n; ++i) {
			if (i & 1) {
				// �뾶��߳��Ǹ�2���Ĺ�ϵ
				r /= sqrt(2);
				glutTools::drawCircle(p, r);
			} else {
				// ���������ε��ĸ�����
				glutTools::drawLine(p + glutTools::point(0, r), p - glutTools::point(r, 0));
				glutTools::drawLine(p - glutTools::point(r, 0), p - glutTools::point(0, r));
				glutTools::drawLine(p - glutTools::point(0, r), p + glutTools::point(r, 0));
				glutTools::drawLine(p + glutTools::point(r, 0), p + glutTools::point(0, r));
			}
		}
	}
	void onDisplay() {
		glClear(GL_COLOR_BUFFER_BIT);
		// ���滭״̬ʱ����
		if (cvalue == hw1_CIRCLEINRECT)	circle_in_rect(n);
		if (glutTools::showGrid)	glutTools::drawGrid();
		glutSwapBuffers();
	}
	void onMenu(int value) {
		if (value == CLEAR) {
			// ���
			clear();
			glutPostRedisplay();
		} else if (value == EXIT) {
			// �˳�
			exit(0);
		} else if (value == GRID) {
			// ������
			glutTools::showGrid = !glutTools::showGrid;
			glutPostRedisplay();
		} else {
			// ����
			if (value != cvalue)	n = 0;
			cvalue = value;
		}
	}
	void onMousePress(int button, int state, int x, int y) {
		switch (cvalue) {
		case hw1_CIRCLEINRECT:
			// �������
			if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
				// �滭��������
				n++;
			}
			break;
		default:
			break;

		}
		glutPostRedisplay();
	}
	void clear() {
		cvalue = n = 0;
		glClear(GL_COLOR_BUFFER_BIT);
		glutSwapBuffers();
	}
};

#endif //__hw1__
