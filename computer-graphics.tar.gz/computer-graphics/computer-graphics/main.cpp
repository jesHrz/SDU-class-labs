#include "hw1.cpp"
#include "hw2.cpp"
#include "hw3.cpp"
#include "hw4.cpp"
#include "hw5.cpp"

int main() {
	glutApp *app[4];
	app[0] = new hw1;
	app[1] = new hw2;
	app[2] = new hw3;
	app[3] = new hw4;
	auto it = new hw5;
	//app[0]->run();
	//it->run();
	for (int i = 0; i < 4; ++i)	delete app[i];
	delete it;
	return 0;
}