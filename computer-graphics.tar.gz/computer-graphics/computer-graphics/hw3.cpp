#ifndef __hw3__
#define __hw3__

#include <GL/glut.h>
#include <algorithm>
#include <vector>
#include "glutApp.h"
#include "glutTools.h"

using namespace std;

const int hw3_DRAWLINE = 1;
const int hw3_DRAWPOLY = 2;
const int hw3_CLIP = 3;

// ������
struct Rect {
	// ���ϵ� �� ���µ�
	int xl, xr, yb, yt;
	// �Ƿ���Ч
	bool available;
	Rect() { xl = xr = yb = yt = 0, available = 0; }
	Rect(glutTools::point top_in, glutTools::point bottom_out) : xl(top_in.x), xr(bottom_out.x), yb(bottom_out.y), yt(top_in.y) { available = 1; };
	// תֱ�߱���
	vector<glutTools::Line> toLine() const {
		vector<glutTools::Line> ret;
		ret.push_back(glutTools::Line(glutTools::point(xl, yt), glutTools::point(xl, yb)));
		ret.push_back(glutTools::Line(glutTools::point(xl, yb), glutTools::point(xr, yb)));
		ret.push_back(glutTools::Line(glutTools::point(xr, yb), glutTools::point(xr, yt)));
		ret.push_back(glutTools::Line(glutTools::point(xr, yt), glutTools::point(xl, yt)));
		return ret;
	}
};

class hw3 :public glutApp {
public:
	hw3(int argc = 0, char** argv = nullptr) {
		init(argc, argv);
		// ���ñ���
		setWindowTitle("hw3");
	}
private:
	// ����״̬ ���״̬
	int opState, mouseState;
	// �ƶ�����ʱѡ�еĶ˵�
	glutTools::point* it;
	// ���λ��
	glutTools::point cur[2];
	// ��ʱ�����  ��  �����߶�
	vector<glutTools::Line> vpoly, lines;
	// ���еĶ���� vpoly���ջᱻ����polys
	vector<vector<glutTools::Line>> polys;
	// �ü�����
	Rect rect;
	static bool ClipT(int p, int q, float& u1, float& u2) {
		// pu<=q;
		float r = 1.0 * q / p;
		if (p < 0) {
			if (r > u2) return false;
			u1 = max(u1, r);
		} else if (p > 0) {
			if (r < u1) return false;
			u2 = min(u2, r);
		} else {
			return q >= 0;
		}
		return true;
	}
	// ���Ѷ��㷨 ֱ�߲ü�
	static void LB_LineClip(glutTools::Line l, Rect R, glutTools::Color cliped_color = glutTools::CLIPED_COLOR) {
		float u1 = 0, u2 = 1;
		int dx = l.p1.x - l.p0.x, dy = l.p1.y - l.p0.y;
		int XL = R.xl, XR = R.xr, YB = R.yb, YT = R.yt;
		if (ClipT(-dx, l.p0.x - XL, u1, u2) && ClipT(dx, XR - l.p0.x, u1, u2) && ClipT(-dy, l.p0.y - YT, u1, u2) && ClipT(dy, YB - l.p0.y, u1, u2)) {
			glutTools::point in = glutTools::point(l.p0.x + int(u1 * dx), l.p0.y + int(u1 * dy));
			glutTools::point out = glutTools::point(l.p0.x + int(u2 * dx), l.p0.y + int(u2 * dy));
			// ԭʼ�߶�
			// glutTools::drawLine(l.p0, in), glutTools::drawLine(out, l.p1);
			// ���ü�����
			glutTools::drawLine(in, out, cliped_color);
		} else {
			// δ���ü�
			// glutTools::drawLine(l.p0, l.p1);
		}
	}
	// ����βü�
	static void SH_PolyClip(const vector<glutTools::Line>& poly, Rect R, glutTools::Color cliped_color = glutTools::CLIPED_COLOR) {
		vector<glutTools::Line> rLine = R.toLine();
		vector<glutTools::point> out;
		for (auto& l : poly) out.push_back(l.p0);
		for (int j = 0; j < rLine.size(); ++j) {
			glutTools::Line& rl = rLine[j];
			vector<glutTools::point> next;
			// ���
			if (rl.p0.x == rl.p1.x) {
				int x = rl.p0.x;
				for (int i = 0; i < out.size(); ++i) {
					glutTools::point p0 = out[i], p1 = out[(i + 1) % out.size()];
					glutTools::Line l = glutTools::Line(p0, p1);
					// �ཻ
					if ((p0.x - x) * (p1.x - x) <= 0) {
						if (p0.x == p1.x) continue;
						int y = p0.y - (p0.y - p1.y) * (p0.x - x) / (p0.x - p1.x);
						next.push_back(glutTools::point(x, y));
						if ((rl ^ l) >= 0) {
							next.push_back(p1);
							// ���ü�����
							// glutTools::drawLine(p0, glutTools::point(x, y));
						} else {
							// ���ü�����
							// glutTools::drawLine(glutTools::point(x, y), p1);
						}
					} else if ((j == 0 && x <= min(p0.x, p1.x)) || (j == 2 && x >= max(p0.x, p1.x))) {
						// ��ȫ���ڲ�
						next.push_back(p1);
					} else {
						// δ���ü�
						// glutTools::drawLine(p0, p1);
					}
				}
			}
			// ����
			if (rl.p0.y == rl.p1.y) {
				int y = rl.p0.y;
				for (int i = 0; i < out.size(); ++i) {
					glutTools::point p0 = out[i], p1 = out[(i + 1) % out.size()];
					glutTools::Line l = glutTools::Line(p0, p1);
					// �ཻ
					if ((p0.y - y) * (p1.y - y) <= 0) {
						if (p0.y == p1.y) continue;
						int x = p0.x - (p0.x - p1.x) * (p0.y - y) / (p0.y - p1.y);
						next.push_back(glutTools::point(x, y));
						if ((rl ^ l) >= 0) {
							next.push_back(p1);
							// ���ü�����
							// glutTools::drawLine(p0, glutTools::point(x, y));
						} else {
							// ���ü�����
							// glutTools::drawLine(glutTools::point(x, y), p1);
						}
					} else if ((j == 1 && y >= max(p0.y, p1.y)) || (j == 3 && y <= min(p0.y, p1.y))) {
						// ��ȫ���ڲ�
						next.push_back(p1);
					} else {
						// δ���ü�
						// glutTools::drawLine(p0, p1);
					}
				}
			}
			out = next;
		}
		// ����������
		for (int i = 0; i < out.size(); ++i) {
			glutTools::point p0 = out[i], p1 = out[(i + 1) % out.size()];
			glutTools::drawLine(p0, p1, cliped_color, 0, glutTools::FILL_COLOR);
		}
	};
	glutTools::point* getElementByPos(const glutTools::point& p) {
		int epsilon = 50;
		for (int i = 0; i < lines.size(); ++i) {
			if (glutTools::Line(p, lines[i].p0).abs2() <= epsilon)	return &lines[i].p0;
			if (glutTools::Line(p, lines[i].p1).abs2() <= epsilon)	return &lines[i].p1;
		}
		return nullptr;
	}
	void onInit() {
		glClearColor(glutTools::WINDOW_COLOR.r, glutTools::WINDOW_COLOR.g, glutTools::WINDOW_COLOR.b, 1);
		glClear(GL_COLOR_BUFFER_BIT);
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		gluOrtho2D(0, getWindowWidth(), getWindowHeight(), 0);

		// ���Ӳ˵���
		addMenuEntry("drawLine", hw3_DRAWLINE);
		addMenuEntry("drawPoly", hw3_DRAWPOLY);
		addMenuEntry("Clip", hw3_CLIP);
		addMenuEntry("Grid on/off", GRID);
		addMenuEntry("Clear", CLEAR);
		addMenuEntry("Exit", EXIT);
		it = nullptr;
		opState = mouseState = 0;
		printf("Liang-Barskyֱ�߲ü��㷨 & ����βü�\n");
		printf("M,m �ڻ����߶�״̬���޸��߶ζ˵�\n");
	}
	void clear() {
		lines.clear();
		polys.clear();
		vpoly.clear();
		it = nullptr;
		cvalue = 0, opState = mouseState = 0;
		rect.available = 0;
		glutPostRedisplay();
	}
	void update() {
		switch (cvalue) {
		case hw3_DRAWLINE:
		{
			if (lines.size() == 0 || lines[lines.size() - 1].p0 != cur[0]) {
				// ���µ�ǰ�߶� ������޸���������߶�
				lines.push_back({ cur[0], cur[1] });
			} else {
				// ���û���޸���һֱ����
				lines[lines.size() - 1].p1 = cur[1];
			}
		} break;
		case hw3_DRAWPOLY:
		{
			if (vpoly.size() == 0 || vpoly[vpoly.size() - 1].p0 != cur[0]) {
				// ���µ�ǰ�߶� ������޸���������߶�
				vpoly.push_back({ cur[0], cur[1] });
			} else {
				// ���û���޸���һֱ����
				vpoly[vpoly.size() - 1].p1 = cur[1];
			}
		} break;
		case hw3_CLIP:
		{
			// ��֤�������ϵ������Ϸ������µ������·�
			int minx = cur[0].x, maxx = cur[1].x;
			int miny = cur[0].y, maxy = cur[1].y;
			if (minx > maxx) swap(minx, maxx);
			if (miny > maxy) swap(miny, maxy);
			// �ж��Ƿ�Ϊ����
			if (minx == maxx || miny == maxy) return;
			rect = Rect(glutTools::point(minx, miny), glutTools::point(maxx, maxy));
		} break;
		default:
			break;
		}
		glutPostRedisplay();
	}
	void onMenu(int value) {
		if (value == CLEAR) {
			clear();
			glutPostRedisplay();
		} else if (value == EXIT) {
			exit(0);
		} else if (value == GRID) {
			glutTools::showGrid = !glutTools::showGrid;
			glutPostRedisplay();
		} else {
			// ��������˵��л��������ǰ���ƵĶ����
			if (cvalue != value) {
				it = nullptr;
				opState = mouseState = 0;
				vpoly.clear();
			}
			cvalue = value;
		}
	}
	void onMousePress(int button, int state, int x, int y) {
		switch (cvalue) {
		case hw3_DRAWLINE:
		{
			// ������¿�ʼ
			if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN && mouseState == 0) {
				cur[mouseState] = glutTools::point(x, y);
				// �����޸�״̬
				if (opState == 109) {
					// ��ȡѡ�ж˵�ָ��
					it = getElementByPos(cur[mouseState]);
					if (it != nullptr) mouseState = 1;
				} else {
					mouseState = 1;
				}
			}
			// �϶�����ֱ��ֱ�����̧��
			if (button == GLUT_LEFT_BUTTON && state == GLUT_UP && mouseState == 1) {
				cur[mouseState] = glutTools::point(x, y);
				mouseState = 0;
				// �����޸�״̬
				if (opState == 0)	update();
			}
		} break;
		case hw3_DRAWPOLY:
		{
			// ������¸���״̬
			if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
				cur[mouseState] = glutTools::point(x, y);
				if (mouseState == 0) {
					mouseState = 1;
					// ����Ҽ��˵���
					glutDetachMenu(GLUT_RIGHT_BUTTON);
				} else {
					update();
					cur[0] = cur[1];
				}
			}
			// ��������λ���
			if (button == GLUT_RIGHT_BUTTON && state == GLUT_UP && mouseState == 1) {
				glutAttachMenu(GLUT_RIGHT_BUTTON);
				if (vpoly.size() < 2) {
					mouseState = 0;
					vpoly.clear();
					return;
				}
				cur[mouseState] = vpoly[0].p0;
				update();
				polys.push_back(vpoly);
				vpoly.clear();
				mouseState = 0;
			}
		} break;
		case hw3_CLIP:
		{
			// ����϶����Ʋü�����
			if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN && mouseState == 0) {
				cur[mouseState] = glutTools::point(x, y);
				mouseState = 1;
			}
			// �����ü����ڻ���
			if (button == GLUT_LEFT_BUTTON && state == GLUT_UP && mouseState == 1) {
				cur[mouseState] = glutTools::point(x, y);
				mouseState = 0;
				update();
			}
		} break;
		default:
			break;
		}
	}
	void onMouseMove(int x, int y) {
		if (cvalue < 1) return;
		// ��ȡ��굱ǰλ�� ������
		cur[mouseState] = glutTools::point(x, y);
		if (mouseState == 1) update();
	}
	void onMousePressMove(int x, int y) {
		// �޸�״̬
		if (cvalue == hw3_DRAWLINE && opState == 109 && mouseState == 1 && it != nullptr) {
			it->x = x, it->y = y;
			glutPostRedisplay();
		} else if (cvalue > 0) {
			// ��ȡ��ǰ���λ�� ������
			cur[mouseState] = glutTools::point(x, y);
			if (mouseState == 1)	update();
		}
	}
	void onKeyDown(unsigned char key, int x, int y) {
		switch (key) {
		case 109:
			// ֻ���ڻ����߶ε�ʱ�������޸�
			if (cvalue != hw3_DRAWLINE) {
				opState = 0;
				break;
			}
			if (opState == 109) {
				opState = 0;
				printf("�˳�\n");
			} else {
				opState = 109;
				printf("��ǰģʽ: �˵��޸�\n");
			}
			break;
		default:
			break;
		}
	}
	void onDisplay() {
		glClearColor(glutTools::WINDOW_COLOR.r, glutTools::WINDOW_COLOR.g, glutTools::WINDOW_COLOR.b, 1);
		glClear(GL_COLOR_BUFFER_BIT);
		glutTools::Color::readVertexRGB();
		// ����ǰ�����
		for (auto& l : vpoly) glutTools::drawLine(l.p0, l.p1);
		// ����вü�����
		if (rect.available) {
			// ���ü�����
			for (auto& l : rect.toLine()) glutTools::drawLine(l.p0, l.p1, glutTools::FILL_COLOR);
			// ��ֱ�߲ü�
			for (auto& l : lines) LB_LineClip(l, rect);
			for (auto& poly : polys) SH_PolyClip(poly, rect), glutTools::Color::readVertexRGB();
		} else {
			// ��ֱ��
			for (auto& l : lines) glutTools::drawLine(l.p0, l.p1);
			// �������
			for (auto& poly : polys)
				for (auto& l : poly) glutTools::drawLine(l.p0, l.p1);
		}
		if (glutTools::showGrid) glutTools::drawGrid(GRID_ROWS, GRID_COLS);
		glutSwapBuffers();
	}
};


#endif //__hw3__
