#ifndef __glutApp__
#define __glutApp__


class glutApp {
public:
	typedef void (*menuFunc)(void);
	// 当前选中菜单
	int cvalue;
	struct MenuEntry {
		int id;
		const char* name;
		menuFunc callback;
	};
	// 构造函数
	glutApp();
	~glutApp();
	// 当前实例指针
	static glutApp* pCurrentApp;
	// 初始化
	static void init(int argc, char** argv) { s_argc = argc, s_argv = argv; };
	// 设置显示模式
	void setDisplayMode(unsigned int mode) { displayMode = mode; };
	// 设置窗口大小
	void setWindowSize(unsigned int width, unsigned int height) { winWidth = width, winHeight = winHeight; };
	// 设置窗口位置
	void setWindowPos(unsigned int winPosX, unsigned int winPosY) { winTop = winPosX, winLeft = winPosY; };
	// 设置窗口标题
	void setWindowTitle(const char* title) { this->title = title; };
	// 运行
	void run();
	// 添加菜单项
	void addMenuEntry(const char* name, int id, menuFunc callback = nullptr);
	// 获取窗口的长和宽
	int getWindowWidth() const { return winWidth; }
	int getWindowHeight() const { return winHeight; }

	// 初始化
	virtual void onInit();
	// 空闲
	virtual void onIdle() {};
	// 绘制 子类需重写
	virtual void onDisplay() = 0;
	// 窗口大小改变
	virtual void onResize() {};
	///////////////////////////////////////////////////
	// 响应键盘事件
	// 一般键盘
	virtual void onKey(unsigned char key, int x, int y) {};
	// 键盘按下
	virtual void onKeyDown(unsigned char key, int x, int y) {};
	///////////////////////////////////////////////////
	// 响应鼠标事件
	// 鼠标按下
	virtual void onMousePress(int button, int state, int x, int y) {};
	// 鼠标移动
	virtual void onMouseMove(int x, int y) {};
	// 鼠标拖动
	virtual void onMousePressMove(int x, int y) {};
	// 菜单回调
	virtual void onMenu(int id) {};

protected:
	// 菜单注册
	void menuRegister();
	// 菜单回调
	static void menuCallback(int id);
	// 键盘事件回调
	static void keyboardCallback(unsigned char key, int x, int y);
	static void keyboardUpCallback(unsigned char key, int x, int y);
	// 鼠标按下回调
	static void mousePressCallback(int button, int state, int x, int y);
	// 鼠标移动回调
	static void mouseMoveCallback(int x, int y);
	// 鼠标拖动回调
	static void mousePressMoveCallback(int x, int y);
	// 空闲回调
	static void idleCallback();
	// 绘制回调
	static void displayCallback();

private:
	// 菜单最大项数
	static const unsigned int MAX_MENU = 32;
	static int s_argc;
	static char** s_argv;
	// 窗口标题
	const char* title;

	// 显示模式
	unsigned int displayMode;
	// 窗口的宽和高
	unsigned int winWidth, winHeight;
	// 窗口左上角的位置
	unsigned int winTop, winLeft;
	// 菜单数量
	int menuCount;
	// 菜单列表
	MenuEntry menuEntry[MAX_MENU];
};

#endif