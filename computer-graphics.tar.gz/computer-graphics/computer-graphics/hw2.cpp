#ifndef __hw2__
#define __hw2__

#include <GL/glut.h>
#include <vector>
#include "glutApp.h"
#include "glutTools.h"

using namespace std;

const int hw2_DRAWPOLY = 1;

// ɨ�������
class hw2 :public glutApp {
public:
	hw2(int argc = 0, char** argv = nullptr) {
		init(argc, argv);
		// ���ñ���
		setWindowTitle("hw2");
	}
private:
	// ���״̬
	int mouseState;
	// �����ʷλ��
	glutTools::point cur[2];
	// ��ǰ�����
	vector<glutTools::Line> vpoly;
	// �����
	vector<vector<glutTools::Line>> polys;
	void onInit() {
		glClearColor(glutTools::WINDOW_COLOR.r, glutTools::WINDOW_COLOR.g, glutTools::WINDOW_COLOR.b, 1);
		glClear(GL_COLOR_BUFFER_BIT);
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		gluOrtho2D(0, getWindowWidth(), getWindowHeight(), 0);

		// ���Ӳ˵���
		addMenuEntry("drawPoly", hw2_DRAWPOLY);
		addMenuEntry("Grid on/off", GRID);
		addMenuEntry("Clear", CLEAR);
		addMenuEntry("Exit", EXIT);
		mouseState = 0;
		printf("ɨ�����������\n");
	}
	void clear() {
		cvalue = mouseState = 0;
		vpoly.clear();
		polys.clear();
		glClear(GL_COLOR_BUFFER_BIT);
		glutSwapBuffers();
	}
	void update() {
		switch (cvalue) {
		case hw2_DRAWPOLY:
			// ���µ�ǰ�߶� ������޸���������߶�
			if (vpoly.size() == 0 || vpoly[vpoly.size() - 1].p0 != cur[0]) {
				vpoly.push_back({ cur[0], cur[1] });
			} else { 
				// ���û���޸���һֱ����
				vpoly[vpoly.size() - 1].p1 = cur[1];
			}
			break;
		default:
			break;
		}
		glutPostRedisplay();
	}
	void onMenu(int value) {
		if (value == CLEAR) {
			// ���
			clear();
		} else if (value == EXIT) {
			// �˳�
			exit(0);
		} else if (value == GRID) {
			// ������
			glutTools::showGrid = !glutTools::showGrid;
			glutPostRedisplay();
		} else {
			if (value != cvalue) {}
			cvalue = value;
		}
	}
	void onMousePress(int button, int state, int x, int y) {
		switch (cvalue) {
		case hw2_DRAWPOLY:
			// ������� ��ʼ���ƶ����
			if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
				cur[mouseState] = glutTools::point(x, y);
				if (mouseState == 0) {
					mouseState = 1;
					glutDetachMenu(GLUT_RIGHT_BUTTON);
				} else {
					update();
					cur[0] = cur[1];
				}
			}
			// �Ҽ����� ��������λ���
			if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN) {
				glutAttachMenu(GLUT_RIGHT_BUTTON);
				if (vpoly.size() < 2) {
					mouseState = 0;
					vpoly.clear();
					return;
				}
				cur[mouseState] = vpoly[0].p0;
				update();
				polys.push_back(vpoly);
				vpoly.clear();
				mouseState = 0;
			}
			break;
		}
	}
	void onMouseMove(int x, int y) {
		switch (cvalue) {
		case hw2_DRAWPOLY:
			// ����ƶ�ʱ���µ�ǰ�߶εĵ�p1
			cur[mouseState] = glutTools::point(x, y);
			if (mouseState == 1) {
				update();
			}
			break;
		}
	}
	void onDisplay() {
		glClear(GL_COLOR_BUFFER_BIT);
		for (auto& p : polys) {
			// ɨ�������
			glutTools::Xscan(p);
			for (auto& l : p)	glutTools::drawLine(l.p0, l.p1);
		}
		for (auto& l : vpoly)	glutTools::drawLine(l.p0, l.p1);
		if (glutTools::showGrid)	glutTools::drawGrid();
		glutSwapBuffers();
	}
};

#endif //__hw2__
