#ifndef __glutTools__
#define __glutTools__

#include <GL/glut.h>
#include <vector>
#include "glutApp.h"

const int CLEAR = -1;
const int EXIT = -2;
const int GRID = -3;

static const unsigned int GRID_ROWS = 40;
static const unsigned int GRID_COLS = 40;

class glutTools {
public:
	static bool showGrid;
	static const glutApp* app;
	static void setApp(const glutApp* currentApp) { app = currentApp; Color::readVertexRGB();  }
	// ����
	class point {
	public:
		int x, y;
		point() : x(0), y(0) {};
		point(int x, int y) : x(x), y(y) {};
		point operator+(const point& t) const { return point(x + t.x, y + t.y); };
		point operator-(const point& t) const { return point(x - t.x, y - t.y); };
		point operator*(int k) const { return point(x * k, y * k); };
		point operator/(int k) const { return point(x / k, y / k); };
		point& operator=(const point& t) {
			if (this != &t)	this->x = t.x, this->y = t.y;
			return *this;
		};
		bool operator==(const point& t) const { return x == t.x && y == t.y; };
		bool operator!=(const point& t) const { return !(*this == t); };
	};
	// ��ɫ��
	class Color {
	public:
		float r, g, b;
		Color(float r=0, float g=0, float b=0) : r(r), g(g), b(b) {};
		Color(int r, int g, int b) {
			this->r = int2float(r);
			this->g = int2float(g);
			this->b = int2float(b);
		};
		bool operator==(const Color& t) const { return sgn(r - t.r) == 0 && sgn(g - t.g) == 0 && sgn(b - t.b) == 0; };
		bool operator!=(const Color& t) const { return !(*this == t); }
		static void readVertexRGB() {
			if (!vertexRGB)	vertexRGB = new float[(app->getWindowWidth() + 1) * (app->getWindowHeight() + 1) * 3];
			glReadPixels(0, 0, app->getWindowWidth(), app->getWindowHeight(), GL_RGB, GL_FLOAT, vertexRGB);
		}
		static void destroy() { delete []vertexRGB; }
		static Color get(const point p);
		static void set(const point p, const Color color);
	private:
		static float* vertexRGB;
		static float int2float(int x) { return x >= 0 ? (x < 256 ? x / 255.0 : 1.0) : 0.0; }
	};
	// ֱ����
	class Line {
	public:
		point p0, p1;
		Line(point p0, point p1) : p0(p0), p1(p1) {}
		int abs2() const {
			return (p0.x - p1.x) * (p0.x - p1.x) + (p0.y - p1.y) * (p0.y - p1.y);
		}
		int operator^(const Line& t) const {
			point t1 = (p1 - p0);
			point t2 = (t.p1 - t.p0);
			return -(t1.x * t2.y - t1.y * t2.x);
		}
		int operator*(const Line& t) const {
			point t1 = (p1 - p0);
			point t2 = (t.p1 - t.p0);
			return t1.x * t2.x + t1.y * t2.y;
		}
		bool parallelTo(const Line& t) const { return (*this ^ t) == 0 && (*this * t) > 0; }
	};
	// ����ɫ
	static const Color VERTEX_COLOR;
	// ������ɫ
	static const Color WINDOW_COLOR;
	// ������ɫ
	static const Color GRID_COLOR;
	// �����ɫ
	static const Color FILL_COLOR;
	// ����ɫ
	static const Color LINE_COLOR;
	// �ü���ɫ
	static const Color CLIPED_COLOR;
	// ����
	static void drawVertex(const point, const Color = VERTEX_COLOR);
	// ����
	static void drawLine(const point, const point, const Color = LINE_COLOR, bool overlap = 1, const Color = LINE_COLOR);
	// ��Բ
	static void drawCircle(const point, int, const Color = LINE_COLOR);
	// ������
	static void drawGrid(unsigned int = GRID_ROWS, unsigned int = GRID_COLS, const Color = GRID_COLOR);
	// ɨ�������
	static void Xscan(std::vector<Line>);

private:
	static int step;
	static float eps;
	static int sgn(float x) { return x < -eps ? -1 : x > eps; }
	static int cmp(float x, float y) { return sgn(x - y); }
};

#endif //__glutTools__