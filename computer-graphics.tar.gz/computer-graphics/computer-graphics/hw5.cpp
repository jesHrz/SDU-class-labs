#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <map>
#include <queue>
using namespace std;
class hw5 {
public:
	void run() {
		puts("����������ˮ�����ݻ���Ŀ��ˮ�������");
		scanf("%d%d%d", &a, &b, &c);
		int ans = solve();
		if (ans == -1)	puts("�޽�");
		else {
			printf("��С������: %d\n", ans);
			printf("һ�ֿ��н�Ϊ:\n");
			for (auto p : path)	printf("=> (%d, %d)\n", p.first, p.second);
		}
		system("pause");
	}
private:
	int a, b, c;
	map<pair<int, int>, pair<int, int>> pre;
	vector<pair<int, int>> path;
	struct node {
		int a, b;
		int step;
	};
	int gcd(int a, int b) { return b == 0 ? a : gcd(b, a % b); }
	int solve() {
		// gcd(a, b)|c ʱ�н�
		if (c % gcd(a, b))	return -1;
		queue<node> que;
		que.push({ 0, 0, 0 });
		pre[{0, 0}] = { -1, -1 };
		while (!que.empty()) {
			node cur = que.front();
			que.pop();
			// �ҵ���
			if (cur.a == c || cur.b == c) {
				// �ݹ�Ѱ��·��
				getPath({ cur.a, cur.b });
				return cur.step;
			}
			// a����
			if (cur.a != 0 && !pre.count({ 0, cur.b })) {
				que.push({ 0, cur.b, cur.step + 1 });
				pre[{0, cur.b}] = { cur.a, cur.b };
			}
			// b����
			if (cur.b != 0 && !pre.count({ cur.a, 0 })) {
				que.push({ cur.a, 0, cur.step + 1 });
				pre[{cur.a, 0}] = { cur.a, cur.b };
			}
			// aʢ��
			if (cur.a != a && !pre.count({ a, cur.b })) {
				que.push({ a, cur.b, cur.step + 1 });
				pre[{a, cur.b}] = { cur.a, cur.b };
			}
			// bʢ��
			if (cur.b != b && !pre.count({ cur.a, b })) {
				que.push({ cur.a, b, cur.step + 1 });
				pre[{cur.a, b}] = { cur.a, cur.b };
			}
			// a��b��
			int diff = min(cur.a, b - cur.b);
			if (!pre.count({ cur.a - diff, cur.b + diff })) {
				que.push({ cur.a - diff, cur.b + diff, cur.step + 1 });
				pre[{cur.a - diff, cur.b + diff}] = { cur.a, cur.b };
			}
			// b��a��
			diff = min(a - cur.a, cur.b);
			if (!pre.count({ cur.a + diff, cur.b - diff })) {
				que.push({ cur.a + diff, cur.b - diff, cur.step + 1 });
				pre[{cur.a + diff, cur.b - diff}] = { cur.a, cur.b };
			}
		}
		return -1;
	}
	void getPath(pair<int, int> cur) {
		if (cur == make_pair(0, 0)) {
			path.push_back(cur);
			return;
		}
		getPath(pre[cur]);
		path.push_back(cur);
	}
};