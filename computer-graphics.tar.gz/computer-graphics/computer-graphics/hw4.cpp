#ifndef __hw4__
#define __hw4__

#include "glutApp.h"
#include "glutTools.h"
#include <GL/glut.h>
#include <algorithm>
#include <vector>
#include <utility>

using namespace std;

const int hw4_BEZIER = 1;
const int hw4_BSPLINE = 2;

class hw4 : public glutApp {
public:
	hw4(int argc = 0, char** argv = nullptr) {
		init(argc, argv);
		setWindowTitle("hw4");
	}
private:
	// �޸�״̬
	int opState;
	// ���� Ĭ��3
	int k = 3;
	// �Ƿ������޸�
	bool startMove;
	// ��굱ǰ��
	glutTools::point cur;
	// ���Ƶ�
	vector<glutTools::point> ctl;
	// ���Ƶ������
	vector<glutTools::point>::iterator it;
	// bezier����
	static void drawBezierCurve(const vector<glutTools::point>& contrl) {
		if (contrl.size() <= 0)	return;
		glutTools::point last;
		glPointSize(3);
		for (double t = 0; t <= 1.00; t += 0.005) {
			vector<pair<double, double>> next, now;
			for (auto p : contrl)	now.push_back(make_pair(p.x, p.y));
			while (now.size() > 1) {
				next.clear();
				for (int i = 1; i < now.size(); ++i) {
					double p0x = now[i - 1].first;
					double p0y = now[i - 1].second;
					double p1x = now[i].first;
					double p1y = now[i].second;
					// ͨ����һ�׶εĵ���µ�ǰ��
					next.push_back(make_pair((1 - t) * p0x + t * p1x, (1 - t) * p0y + t * p1y));
				}
				now = next;
			}
			if (t > 0)
				//glutTools::drawVertex(last, glutTools::LINE_COLOR);
			glutTools::drawLine(last, glutTools::point(now[0].first, now[0].second));
			last.x = now[0].first;
			last.y = now[0].second;
		}
	};
	// B�������� de Boor-Cox
	static void drawBSplineCurve(const vector<glutTools::point>& contrl, int K) {
		if (contrl.size() <= 0)	return;
		glPointSize(1);
		// ֧������
		vector<double> T;
		for (int i = 0; i <= contrl.size() + K + 1; ++i)	T.push_back(i);

		vector<glutTools::point>* p = new vector<glutTools::point>[K];
		p[0] = contrl;
		for (int i = 1; i < K; ++i)	p[i].resize(contrl.size());

		for (double t = 0; t <= 1; t += 0.001) {
			for (int i = K - 1; i < contrl.size(); ++i) {
				// ������ȡ��ǰ�����
				double a = T[i] + (T[i + 1] - T[i]) * t;
				for (int r = 1; r < K; r++) {
					for (int j = i - K + r + 1; j <= i; ++j) {
						// ϵ��
						double d = 0;
						if (T[j + K - r] - T[j] != 0)	d = (a - T[j]) / (T[j + K - r] - T[j]);
						// ���µ�ǰ����
						p[r][j].x = int(d * p[r - 1][j].x + (1 - d) * p[r - 1][j - 1].x);
						p[r][j].y = int(d * p[r - 1][j].y + (1 - d) * p[r - 1][j - 1].y);
					}
				}
				// ����K�׵�
				glutTools::drawVertex(p[K - 1][i], glutTools::LINE_COLOR);
			}
		}
		delete[] p;
	};
	// Ѱ�Ҿ����p����Ŀ��Ƶ�
	int getElementByPos(const glutTools::point& p) {
		int epsilon = 50;
		int i = 0;
		while (i < ctl.size()) {
			if (glutTools::Line(p, ctl[i]).abs2() <= epsilon)	return i;
			i++;
		}
		return i;
	};
	void onInit() {
		glClearColor(glutTools::WINDOW_COLOR.r, glutTools::WINDOW_COLOR.g, glutTools::WINDOW_COLOR.b, 1);
		glClear(GL_COLOR_BUFFER_BIT);
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		gluOrtho2D(0, getWindowWidth(), getWindowHeight(), 0);

		addMenuEntry("Bezier", hw4_BEZIER);
		addMenuEntry("B-Spline", hw4_BSPLINE);
		addMenuEntry("Grid on/off", GRID);
		addMenuEntry("Clear", CLEAR);
		addMenuEntry("Exit", EXIT);
		opState = 0;
		startMove = false;
		printf("Bezier���� & B��������\nBS ɾ�����Ƶ�\nM �޸Ŀ��Ƶ�\nI ������Ƶ�\nK �޸Ľ���\n");
		printf("��ǰB�������߽���: %d\n", k);
	}
	void clear() {
		ctl.clear();
		cvalue = 0;
		opState = 0;
		startMove = 0;
		k = 4;
		glutPostRedisplay();
	};
	void update() {
		switch (cvalue) {
		case hw4_BEZIER:
		case hw4_BSPLINE:
			ctl.push_back(cur);
			break;
		default:
			break;
		}
		glutPostRedisplay();
	};
	void onMenu(int value) {
		if (value == CLEAR) {
			clear();
			glutPostRedisplay();
		} else if (value == EXIT) {
			exit(0);
		} else if (value == GRID) {
			glutTools::showGrid = !glutTools::showGrid;
			glutPostRedisplay();
		} else {
			cvalue = value;
		}
	};
	void onMousePress(int button, int state, int x, int y) {
		switch (cvalue) {
		case hw4_BEZIER:
		case hw4_BSPLINE:
			// ������� �����Ƶ�
			if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
				cur = glutTools::point(x, y);
				if (opState == 109) {
					it = ctl.begin() + getElementByPos(cur);
					if (it != ctl.end())	startMove = true;
				} else if (opState == 105) {
					if (!startMove) {
						it = ctl.begin() + getElementByPos(cur);
						if (it != ctl.end())	startMove = true;
					} else {
						ctl.insert(it + 1, cur);
						startMove = false;
					}
				} else {
					update();
				}
			}
			// �������Ƶ���ƶ�
			if (button == GLUT_LEFT_BUTTON && state == GLUT_UP) {
				if (opState == 109) {
					startMove = false;
				}
			}
			break;
		default:
			break;
		}
	};
	void onMousePressMove(int x, int y) {
		switch (opState) {
		case 109:
			if (startMove) {
				it->x = x, it->y = y;
			}
			break;
		}
		glutPostRedisplay();
	}
	void onKeyDown(unsigned char key, int x, int y) {
		if (cvalue != hw4_BEZIER && cvalue != hw4_BSPLINE)
			return;
		switch (key) {
		case 8: // ɾ�����Ƶ�
			if (opState == 0 && !startMove) {
				int tar = getElementByPos(glutTools::point(x, y));
				if (tar < ctl.size())
					ctl.erase(ctl.begin() + tar);
			}
			glutPostRedisplay();
			break;
		case 105: // ������Ƶ�
			if (opState == 105 && !startMove) {
				opState = 0;
				printf("�˳�\n");
			} else {
				opState = 105;
				printf("��ǰģʽ: ���Ƶ����\n");
			}
			break;
		case 109: // �ƶ����Ƶ�
			if (opState == 109 && !startMove) {
				opState = 0;
				printf("�˳�\n");
			} else {
				opState = 109;
				printf("��ǰģʽ: ���Ƶ��޸�\n");
			}
			break;
		case 107: // �޸Ľ���
			if (opState == 0) {
				opState = 107;
				int modifyed_k = 0;
				char num[32];
				printf("��ǰģʽ: �����޸�\n");
				printf("B�������߽����޸�Ϊ: ");
				scanf("%s", num);
				for (int i = 0; i <= strlen(num); ++i) {
					if (i == strlen(num)) {
						k = modifyed_k;
						printf("��ǰB�������߲���Ϊ: %d\n", k);
						glutPostRedisplay();
						break;
					}
					if (!isdigit(num[i]))	break;
					modifyed_k = modifyed_k * 10 + num[i] - '0';
				}
				opState = 0;
			}
		default:
			return;
		}
	};
	void onDisplay() {
		glClear(GL_COLOR_BUFFER_BIT);
		glPointSize(5);
		// ���Ƶ�
		for (auto& p : ctl)
			glutTools::drawVertex(p);
		// ���������
		glPointSize(1);
		for (int i = 1; i < ctl.size(); ++i)
			glutTools::drawLine(ctl[i - 1], ctl[i], glutTools::FILL_COLOR);
		// ����
		if (cvalue == hw4_BEZIER)
			drawBezierCurve(ctl);
		if (cvalue == hw4_BSPLINE)
			drawBSplineCurve(ctl, k);
		if (glutTools::showGrid)
			glutTools::drawGrid(GRID_ROWS, GRID_COLS);
		glutSwapBuffers();
	};
};

#endif __hw4__