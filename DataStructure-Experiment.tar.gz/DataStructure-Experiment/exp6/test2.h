#ifndef TEST2_H_
#define TEST2_H_

#include <stack/linkedStack.h>

struct Runtime {
	int x, y;
	int i;
};
void test2();

#endif //TEST2_H_