# DIP-labs

This labs work on macOS 10.15.6. To start up, you should install `opencv` firstly using `brew install opencv@3`

To compile:

```
make
```

To run the binary of one lab:

```
make lab1
```

To clean all files produced during the build process:

```
make clean
```